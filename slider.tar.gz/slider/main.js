/**
 * Created by A.O.Kartuzov on 19.07.17.
 */
function sSlider(arr) { return {
    arr: arr,
    curPos: 0,
    rootNode: null,
    sBody: function() {
        var container = document.createElement('div');
        container.className = 'sld-container';

        var left = document.createElement('div');
        left.className = 'left';
        left.innerHTML = arr[this.getPos('left')];
        left.onclick = function() {this.setPos('left');this.use()}.bind(this);

        var center = document.createElement('div');
        center.className = 'center';
        center.innerHTML = arr[this.curPos];
        center.onclick = function() {this.clickEvent()}.bind(this);

        var right = document.createElement('div');
        right.className = 'right';
        right.innerHTML = arr[this.getPos('right')];
        right.onclick = function() {this.setPos('right');this.use()}.bind(this);

        container.appendChild(left);
        container.appendChild(center);
        container.appendChild(right);

        return container;
    },
    use: function(nodeId) {
        if(nodeId) {
        var elem = document.getElementById(nodeId);
        this.rootNode = elem;
        elem.appendChild(this.sBody());
        }
        else {
            this.rootNode.innerHTML = '';
            this.rootNode.appendChild(this.sBody());
        }

    },
    vfPos: function(pos) {
        pos = +pos;
        var max = this.arr.length - 1;
        if (pos > max) pos = 0;
        if (pos < 0) pos = max;
        return pos;
    },
    getPos: function(type) {
        var pos = this.curPos;
         if (type === 'left') pos = this.vfPos(pos - 1);
         if (type === 'right') pos = this.vfPos(pos + 1);
         return pos;
    },
    setPos: function(type) {
        var pos = this.curPos;
        if (type === 'left') this.curPos = this.vfPos(pos - 1);
        if (type === 'right') this.curPos = this.vfPos(pos + 1);
    },
    clickEvent: function() {return false}
}
}